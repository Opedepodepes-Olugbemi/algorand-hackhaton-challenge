import React from 'react';
import { CheckCircle, ArrowRight } from 'lucide-react';
import type { VerifiedAsset } from '../types/pera';

interface AssetCardProps {
  asset: VerifiedAsset;
  onOptIn: (assetId: number) => void;
}

export function AssetCard({ asset, onOptIn }: AssetCardProps) {
  return (
    <div className="bg-white rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow p-6">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-4">
          <img
            src={asset.logo}
            alt={asset.name}
            className="w-12 h-12 rounded-full object-cover ring-2 ring-yellow-100"
            onError={(e) => {
              (e.target as HTMLImageElement).src = 'https://via.placeholder.com/48';
            }}
          />
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-semibold text-gray-900">{asset.name}</h3>
              {asset.verified && (
                <CheckCircle className="w-4 h-4 text-yellow-500" />
              )}
            </div>
            <p className="text-sm text-gray-500">{asset.unit_name}</p>
          </div>
        </div>
      </div>
      <div className="mt-6">
        <button
          onClick={() => onOptIn(asset.id)}
          className="w-full flex items-center justify-center gap-2 bg-yellow-500 text-white py-2.5 px-4 rounded-xl hover:bg-yellow-600 transition-colors"
        >
          <span>Opt In</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}