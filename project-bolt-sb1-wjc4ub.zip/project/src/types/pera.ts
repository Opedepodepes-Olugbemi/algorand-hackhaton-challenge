export interface VerifiedAsset {
  id: number;
  name: string;
  unit_name: string;
  logo: string;
  total_supply: number;
  verified: boolean;
  creator_address: string;
}

export interface WalletState {
  address: string | null;
  network: 'MainNet' | 'TestNet';
  isConnected: boolean;
}