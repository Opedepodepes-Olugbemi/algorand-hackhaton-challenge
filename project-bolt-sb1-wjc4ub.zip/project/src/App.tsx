import React, { useState, useEffect } from 'react';
import { PeraWalletConnect } from '@perawallet/connect';
import { toast, Toaster } from 'react-hot-toast';
import algosdk from 'algosdk';
import { ConnectButton } from './components/ConnectButton';
import { NetworkSwitch } from './components/NetworkSwitch';
import { AssetCard } from './components/AssetCard';
import { DonationCard } from './components/DonationCard';
import type { VerifiedAsset, WalletState } from './types/pera';
import { Heart } from 'lucide-react';

const peraWallet = new PeraWalletConnect({
  shouldShowSignTxnToast: false
});

// Network configurations
const NETWORKS = {
  MainNet: {
    algod: new algosdk.Algodv2('', 'https://mainnet-api.algonode.cloud', ''),
    indexer: new algosdk.Indexer('', 'https://mainnet-idx.algonode.cloud', ''),
  },
  TestNet: {
    algod: new algosdk.Algodv2('', 'https://testnet-api.algonode.cloud', ''),
    indexer: new algosdk.Indexer('', 'https://testnet-idx.algonode.cloud', ''),
  }
};

// Your wallet address for donations (use different addresses for different networks)
const DONATION_ADDRESSES = {
  MainNet: 'YJ5EFJPM3TYIP23SOOJWVAUVMKBJVGIZCNNIIZO652ZUSSTMGVIGMLC5YM',
  TestNet: 'YJ5EFJPM3TYIP23SOOJWVAUVMKBJVGIZCNNIIZO652ZUSSTMGVIGMLC5YM' // Replace with your testnet address
};

function App() {
  const [walletState, setWalletState] = useState<WalletState>({
    address: null,
    network: 'MainNet',
    isConnected: false,
  });
  const [assets, setAssets] = useState<VerifiedAsset[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Reconnect session
    peraWallet.reconnectSession().then((accounts) => {
      if (accounts.length) {
        setWalletState(prev => ({
          ...prev,
          address: accounts[0],
          isConnected: true,
        }));
      }
    });

    // Fetch verified assets
    fetchVerifiedAssets();
  }, [walletState.network]); // Refetch when network changes

  const fetchVerifiedAssets = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch('https://api.perawallet.app/v1/assets');
      if (!response.ok) {
        throw new Error('Failed to fetch assets');
      }
      const data = await response.json();
      if (data.assets && Array.isArray(data.assets)) {
        setAssets(data.assets.filter((asset: VerifiedAsset) => asset.verified));
      } else {
        throw new Error('Invalid asset data received');
      }
    } catch (error) {
      console.error('Asset fetch error:', error);
      setError('Failed to load verified assets. Please try again later.');
      setAssets([]);
    } finally {
      setLoading(false);
    }
  };

  const handleConnect = async () => {
    try {
      const accounts = await peraWallet.connect();
      setWalletState(prev => ({
        ...prev,
        address: accounts[0],
        isConnected: true,
      }));
      toast.success('Wallet connected successfully!');
    } catch (error) {
      console.error('Connection error:', error);
      toast.error('Failed to connect wallet');
    }
  };

  const handleDisconnect = async () => {
    try {
      await peraWallet.disconnect();
      setWalletState({
        address: null,
        network: walletState.network,
        isConnected: false,
      });
      toast.success('Wallet disconnected');
    } catch (error) {
      console.error('Disconnect error:', error);
      toast.error('Failed to disconnect wallet');
    }
  };

  const handleDonation = async (amount: number) => {
    if (!walletState.address) return;

    try {
      const algodClient = NETWORKS[walletState.network].algod;
      const suggestedParams = await algodClient.getTransactionParams().do();
      
      const txn = algosdk.makePaymentTxnWithSuggestedParamsFromObject({
        from: walletState.address,
        to: DONATION_ADDRESSES[walletState.network],
        amount: Math.floor(amount * 1000000), // Convert ALGO to microALGO
        suggestedParams,
      });

      const singleTxnGroups = [{ txn }];
      const signedTxn = await peraWallet.signTransaction([singleTxnGroups]);
      const { txId } = await algodClient.sendRawTransaction(signedTxn).do();
      
      // Wait for confirmation
      await algosdk.waitForConfirmation(algodClient, txId, 4);
      toast.success('Thank you for your donation! 💚');
    } catch (error) {
      console.error('Donation error:', error);
      toast.error(error instanceof Error ? error.message : 'Donation failed. Please try again.');
    }
  };

  const handleOptIn = async (assetId: number) => {
    if (!walletState.address) return;

    try {
      const algodClient = NETWORKS[walletState.network].algod;
      const suggestedParams = await algodClient.getTransactionParams().do();
      
      const txn = algosdk.makeAssetTransferTxnWithSuggestedParamsFromObject({
        from: walletState.address,
        to: walletState.address,
        assetIndex: assetId,
        amount: 0,
        suggestedParams,
      });

      const signedTxn = await peraWallet.signTransaction([[{ txn }]]);
      const { txId } = await algodClient.sendRawTransaction(signedTxn).do();
      
      // Wait for confirmation
      await algosdk.waitForConfirmation(algodClient, txId, 4);
      toast.success('Asset opt-in successful!');
    } catch (error) {
      console.error('Opt-in error:', error);
      toast.error(error instanceof Error ? error.message : 'Asset opt-in failed');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-yellow-50 to-white">
      <Toaster position="top-right" />
      
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Heart className="w-6 h-6 text-yellow-500" />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-yellow-500 to-yellow-600 bg-clip-text text-transparent">
                PerAlgo
              </h1>
            </div>
            <div className="flex items-center gap-6">
              <NetworkSwitch
                network={walletState.network}
                onNetworkChange={(network) => setWalletState(prev => ({ ...prev, network }))}
              />
              <ConnectButton
                isConnected={walletState.isConnected}
                address={walletState.address}
                onConnect={handleConnect}
                onDisconnect={handleDisconnect}
              />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {walletState.isConnected && (
          <div className="mb-12">
            <DonationCard onDonate={handleDonation} network={walletState.network} />
          </div>
        )}

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">Verified Assets</h2>
          {loading ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-500 mx-auto"></div>
              <p className="mt-4 text-gray-600">Loading assets...</p>
            </div>
          ) : error ? (
            <div className="text-center py-12">
              <p className="text-red-600">{error}</p>
              <button
                onClick={fetchVerifiedAssets}
                className="mt-4 px-4 py-2 bg-yellow-500 text-white rounded-xl hover:bg-yellow-600 transition-colors"
              >
                Try Again
              </button>
            </div>
          ) : assets.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-600">No verified assets found.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {assets.map((asset) => (
                <AssetCard
                  key={asset.id}
                  asset={asset}
                  onOptIn={handleOptIn}
                />
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;